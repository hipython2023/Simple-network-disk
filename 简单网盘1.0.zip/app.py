import os
import json
import shutil
import logging
import datetime
import re
from flask import Flask, request, render_template, redirect, session, send_from_directory

app = Flask(__name__)
app.secret_key = 'your_secret_key'

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data')
users_file = os.path.join(base_dir, 'users.json')
logs_dir = os.path.join(base_dir, 'logs')

# 创建日志文件夹
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 配置日志记录
log_file = os.path.join(logs_dir, f"{datetime.datetime.now().strftime('%Y-%m-%d')}.log")
logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# 创建StreamHandler来将日志输出到终端
stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.INFO)

# 创建Formatter并定义去除颜色代码的函数
class ColorFormatter(logging.Formatter):
    color_pattern = re.compile(r'\x1b[^m]*m')

    def format(self, record):
        message = super().format(record)
        return self.color_pattern.sub('', message)

formatter = ColorFormatter('%(asctime)s - %(levelname)s - %(message)s')
stream_handler.setFormatter(formatter)

logging.getLogger().addHandler(stream_handler)

# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        with open(users_file, 'r') as f:
            users = json.load(f)
        
        if username in users and users[username] == password:
            session['username'] = username
            logging.info(f"User '{username}' logged in")
            return redirect('/')
        else:
            logging.warning(f"Failed login attempt for user '{username}'")
            return render_template('login.html', error='用户名或密码错误')
    
    return render_template('login.html')

# 注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        with open(users_file, 'r') as f:
            users = json.load(f)
        
        if username in users:
            logging.warning(f"Failed registration attempt. Username '{username}' already exists")
            return render_template('register.html', error='用户名已存在')
        
        users[username] = password
        
        with open(users_file, 'w') as f:
            json.dump(users, f, indent=4)
        
        logging.info(f"New user registered. Username: '{username}'")
        return redirect('/login')
    
    return render_template('register.html')

# 登出
@app.route('/logout')
def logout():
    if 'username' in session:
        username = session['username']
        session.pop('username', None)
        logging.info(f"User '{username}' logged out")
    return redirect('/login')

# 主页
@app.route('/')
def index():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        files = os.listdir(user_dir)
        return render_template('index.html', username=username, files=files)
    else:
        return redirect('/login')

# 上传文件
@app.route('/upload', methods=['POST'])
def upload():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        file = request.files['file']
        filename = file.filename
        file.save(os.path.join(user_dir, filename))
        
        logging.info(f"File '{filename}' uploaded by user '{username}'")
    
    return redirect('/')

# 下载文件
@app.route('/download/<username>/<filename>')
def download(username, filename):
    if 'username' in session and session['username'] == username:
        user_dir = os.path.join(data_dir, username)
        file_path = os.path.join(user_dir, filename)
        
        if os.path.isfile(file_path):
            logging.info(f"File '{filename}' downloaded by user '{username}'")
            return send_from_directory(user_dir, filename, as_attachment=True)
        else:
            return render_template('file_does_not_exist.html')
    
    return redirect('/login')

# 新建文件夹
@app.route('/create_folder', methods=['POST'])
def create_folder():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        folder_name = request.form['folder_name']
        new_folder_path = os.path.join(user_dir, folder_name)
        
        if not os.path.exists(new_folder_path):
            os.makedirs(new_folder_path)
        
        logging.info(f"Folder '{folder_name}' created by user '{username}'")
    
    return redirect('/')

# 删除文件或文件夹
@app.route('/delete/<username>/<path:file_path>')
def delete(username, file_path):
    if 'username' in session and session['username'] == username:
        user_dir = os.path.join(data_dir, username)
        abs_file_path = os.path.join(user_dir, file_path)
        
        if os.path.exists(abs_file_path):
            if os.path.isfile(abs_file_path):
                os.remove(abs_file_path)
                logging.info(f"File '{file_path}' deleted by user '{username}'")
            else:
                shutil.rmtree(abs_file_path)
                logging.info(f"Folder '{file_path}' deleted by user '{username}'")
    
    return redirect('/')

if __name__ == '__main__':
    app.run()
