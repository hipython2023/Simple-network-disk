import os
import json
import shutil
from flask import Flask, request, render_template, redirect, session, send_from_directory

app = Flask(__name__)
app.secret_key = 'your_secret_key'

base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data')
users_file = os.path.join(base_dir, 'users.json')

# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        with open(users_file, 'r') as f:
            users = json.load(f)
        
        if username in users and users[username] == password:
            session['username'] = username
            return redirect('/')
        else:
            return render_template('login.html', error='用户名或密码错误')
    
    return render_template('login.html')

# 注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        with open(users_file, 'r') as f:
            users = json.load(f)
        
        if username in users:
            return render_template('register.html', error='用户名已存在')
        
        users[username] = password
        
        with open(users_file, 'w') as f:
            json.dump(users, f, indent=4)
        
        return redirect('/login')
    
    return render_template('register.html')

# 登出
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/login')

# 主页
@app.route('/')
def index():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        files = os.listdir(user_dir)
        return render_template('index.html', username=username, files=files)
    else:
        return redirect('/login')

# 上传文件
@app.route('/upload', methods=['POST'])
def upload():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        file = request.files['file']
        filename = file.filename
        file.save(os.path.join(user_dir, filename))
        
    return redirect('/')

# 下载文件
@app.route('/download/<username>/<filename>')
def download(username, filename):
    if 'username' in session and session['username'] == username:
        user_dir = os.path.join(data_dir, username)
        file_path = os.path.join(user_dir, filename)
        
        if os.path.isfile(file_path):
            return send_from_directory(user_dir, filename, as_attachment=True)
        else:
            return render_template('file_does_not_exist.html')
    
    return redirect('/login')

# 新建文件夹
@app.route('/create_folder', methods=['POST'])
def create_folder():
    if 'username' in session:
        username = session['username']
        user_dir = os.path.join(data_dir, username)
        
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        folder_name = request.form['folder_name']
        new_folder_path = os.path.join(user_dir, folder_name)
        
        if not os.path.exists(new_folder_path):
            os.makedirs(new_folder_path)
        
    return redirect('/')

# 删除文件或文件夹
@app.route('/delete/<username>/<path:file_path>')
def delete(username, file_path):
    if 'username' in session and session['username'] == username:
        user_dir = os.path.join(data_dir, username)
        abs_file_path = os.path.join(user_dir, file_path)
        
        if os.path.exists(abs_file_path):
            if os.path.isfile(abs_file_path):
                os.remove(abs_file_path)
            else:
                shutil.rmtree(abs_file_path)
    
    return redirect('/')

if __name__ == '__main__':
    app.run()